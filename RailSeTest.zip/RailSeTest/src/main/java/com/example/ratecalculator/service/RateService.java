package com.example.ratecalculator.service;

import com.example.ratecalculator.dto.RateRequestDTO;
import com.example.ratecalculator.dto.RateResponseDTO;

public interface RateService {
    RateResponseDTO calculateRate(RateRequestDTO requestDTO);
}