package com.example.ratecalculator.dto;

public class Box {

}
