package com.example.ratecalculator.dto;

import java.util.List;

public class RateRequestDTO {
    private int sourcePincode;
    private int destPincode;
    private List<BoxDTO> boxes;
    private int paymentModeId;
    private int invoiceValue;
    private int codAmount;
    private int riskTypeId;
	public int getSourcePincode() {
		return sourcePincode;
	}
	public void setSourcePincode(int sourcePincode) {
		this.sourcePincode = sourcePincode;
	}
	public int getDestPincode() {
		return destPincode;
	}
	public void setDestPincode(int destPincode) {
		this.destPincode = destPincode;
	}
	public List<BoxDTO> getBoxes() {
		return boxes;
	}
	public void setBoxes(List<BoxDTO> boxes) {
		this.boxes = boxes;
	}
	public int getPaymentModeId() {
		return paymentModeId;
	}
	public void setPaymentModeId(int paymentModeId) {
		this.paymentModeId = paymentModeId;
	}
	public int getInvoiceValue() {
		return invoiceValue;
	}
	public void setInvoiceValue(int invoiceValue) {
		this.invoiceValue = invoiceValue;
	}
	public int getCodAmount() {
		return codAmount;
	}
	public void setCodAmount(int codAmount) {
		this.codAmount = codAmount;
	}
	public int getRiskTypeId() {
		return riskTypeId;
	}
	public void setRiskTypeId(int riskTypeId) {
		this.riskTypeId = riskTypeId;
	}

    // Getters & Setters
}
