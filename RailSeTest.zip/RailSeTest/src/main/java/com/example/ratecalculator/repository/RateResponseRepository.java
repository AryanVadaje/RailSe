package com.example.ratecalculator.repository;

import com.example.ratecalculator.entity.RateResponseEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RateResponseRepository extends JpaRepository<RateResponseEntity, Long> {
}