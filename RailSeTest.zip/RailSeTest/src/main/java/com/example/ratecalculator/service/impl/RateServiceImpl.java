package com.example.ratecalculator.service.impl;

import com.example.ratecalculator.dto.*;
import com.example.ratecalculator.entity.RateResponseEntity;
import com.example.ratecalculator.repository.RateResponseRepository;
import com.example.ratecalculator.service.RateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class RateServiceImpl implements RateService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RateResponseRepository repository;

    private final String externalApiUrl = "https://appapinew.bigship.in/api/RateCalculate";

    @Override
    public RateResponseDTO calculateRate(RateRequestDTO requestDTO) {
        RateResponseDTO response = restTemplate.postForObject(
                externalApiUrl,
                requestDTO,
                RateResponseDTO.class
        );

        RateResponseEntity entity = new RateResponseEntity();
        entity.setStatus(response.getStatus());
        entity.setRawResponse(response.toString());
        repository.save(entity);

        return response;
    }
}