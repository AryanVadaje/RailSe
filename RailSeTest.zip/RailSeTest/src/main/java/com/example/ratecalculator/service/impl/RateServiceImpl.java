package com.example.ratecalculator.service.impl;

import com.example.ratecalculator.dto.*;
import com.example.ratecalculator.entity.RateResponseEntity;
import com.example.ratecalculator.repository.RateResponseRepository;
import com.example.ratecalculator.service.RateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;


@Service
public class RateServiceImpl implements RateService {

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private RateResponseRepository repository;

    private final String externalApiUrl = "https://appapinew.bigship.in/api/RateCalculate";

    @Override
    public RateResponseDTO calculateRate(RateRequestDTO requestDTO) {
        try {
            // 1. Prepare the HTTP request
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<RateRequestDTO> entity = new HttpEntity<>(requestDTO, headers);

            // 2. Call the external API and get raw response as String
            ResponseEntity<String> response = restTemplate.exchange(
                    externalApiUrl,
                    HttpMethod.POST,
                    entity,
                    String.class
            );

            // 3. Save the raw response in the entity (mocked DB)
            RateResponseEntity responseEntity = new RateResponseEntity();
            responseEntity.setStatus("SUCCESS");
            responseEntity.setRawResponse(response.getBody());
            repository.save(responseEntity); // No manual ID setting needed now ✅

            // 4. Return response as DTO
            RateResponseDTO dto = new RateResponseDTO();
            dto.setStatus("SUCCESS");
            dto.setRawResponse(response.getBody());
            return dto;

        } catch (Exception e) {
            RateResponseDTO errorDTO = new RateResponseDTO();
            errorDTO.setStatus("ERROR");
            errorDTO.setRawResponse(e.getMessage());
            return errorDTO;
        }
    }

}