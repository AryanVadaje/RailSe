package com.example.ratecalculator.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class RateResponseEntity {

    @Id
    private Long id;  // Add ID field if necessary for database entity

    private String status;
    private String rawResponse;  // This stores the raw JSON response

    // Getter and Setter for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Getter and Setter for rawResponse
    public String getRawResponse() {
        return rawResponse;
    }

    public void setRawResponse(String rawResponse) {
        this.rawResponse = rawResponse;
    }
}
