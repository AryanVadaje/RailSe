package com.example.ratecalculator.controller;

import com.example.ratecalculator.dto.RateRequestDTO;
import com.example.ratecalculator.dto.RateResponseDTO;
import com.example.ratecalculator.service.RateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rates")
public class RateController {

    @Autowired
    private RateService rateService;

    @PostMapping
    public RateResponseDTO calculateRate(@RequestBody RateRequestDTO requestDTO) {
        return rateService.calculateRate(requestDTO);
    }
}