package com.example.ratecalculator.dto;

public class RateResponseDTO {
    private String status;
    private String rawResponse;  // This is for the raw response body

    // Getter and Setter for status
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Getter and Setter for rawResponse
    public String getRawResponse() {
        return rawResponse;
    }

    public void setRawResponse(String rawResponse) {
        this.rawResponse = rawResponse;
    }
}
