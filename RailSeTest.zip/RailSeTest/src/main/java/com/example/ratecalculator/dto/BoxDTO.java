package com.example.ratecalculator.dto;

public class BoxDTO {
    private String noofbox;
    private String boxlength;
    private String boxwidth;
    private String boxheight;
    private String boxdeadweight;

    public String getNoofbox() {
        return noofbox;
    }

    public void setNoofbox(String noofbox) {
        this.noofbox = noofbox;
    }

    public String getBoxlength() {
        return boxlength;
    }

    public void setBoxlength(String boxlength) {
        this.boxlength = boxlength;
    }

    public String getBoxwidth() {
        return boxwidth;
    }

    public void setBoxwidth(String boxwidth) {
        this.boxwidth = boxwidth;
    }

    public String getBoxheight() {
        return boxheight;
    }

    public void setBoxheight(String boxheight) {
        this.boxheight = boxheight;
    }

    public String getBoxdeadweight() {
        return boxdeadweight;
    }

    public void setBoxdeadweight(String boxdeadweight) {
        this.boxdeadweight = boxdeadweight;
    }
}
